export default function Detail() {
    return (
        <>Detail</>
    )
}