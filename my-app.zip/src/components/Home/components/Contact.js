import './Contact.scss'
export default function Contact() {

    return (
        <body className='tongcontact'>
            <div className='contactlon'>
                <h2 className='contact'>CONTACT</h2>
                <hr className='gachduoicontact'></hr>
            </div>
            <div className='tonglienhe'>
                <div className='lienhe'>
                    <h3 className='address'>ADDRESS</h3>
                    <p className='diachi'>123 Street, New York (USA)</p>
                </div>
                <div className='lienhe'>
                    <h3 className='address'>PHONE</h3>
                    <p className='diachi'>+123 456 789</p>
                </div>
                <div className='lienhe'>
                    <h3 className='address'>EMAIL</h3>
                    <a href="mailto:info@myemail.com">info@myemail.com</a>
                </div>
            </div>
            <div className='tongphananh'>
                <div className='chitietphananh'>
                    <div>
                        <input placeholder='Name*' className='ten' />
                        <hr className='gachduoiphananh'></hr>
                    </div>
                    <div>
                        <input placeholder='Email*' className='ten' />
                        <hr className='gachduoiphananh'></hr>
                    </div>
                </div>
                <textarea rows={10} placeholder='Messenge*' className='ten1' />
               <div className='tongsend'> <button className='send'>SEND</button></div>
            </div>
        </body>
    )
}