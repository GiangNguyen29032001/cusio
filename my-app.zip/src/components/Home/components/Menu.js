import "./Menu.scss"
import image1 from '../../../assets/images/logo192.png'
export default function Menu() {
    return (
        <body className="tonghome">
            <div className="tongmenu">
                <div className="anhlogo">
                    <img src={image1} className="anhlogomenu" />
                </div>
                <div className="menu">
                    <ul className="menunho">
                        <li className="chumenu">HOME</li>
                        <li className="chumenu">ABOUT</li>
                        <li className="chumenu">SERVICES</li>
                        <li className="chumenu">TEAM</li>
                        <li className="chumenu">PORTFOLIO</li>
                        <li className="chumenu">BLOG</li>
                        <li className="chumenu">CONTACT</li>
                    </ul>
                </div>
            </div>
            <div className="phantextcruto">
                <div className="crucio">CRUCIO</div>
                <div className="gachduoicucio"></div>
                <div className="powe">POWERFUL WEBSITE</div>
            </div>
        </body>
    )
}