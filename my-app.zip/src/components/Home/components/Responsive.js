import "./Responsive.scss"
export default function Responsive() {
    return (
        <>
            <body className="tongphanresponsive">
                <div className="responsive">
                    <h2 className="responsive1">RESPONSIVE</h2>
                    <p className="responsive2">Lorem ipsum dolor sit amet, consectetur adipisci elit, sed eiusmod<br />
                        tempor incidunt ut labore et dolore magna aliqua. Ut enim ad minim<br />veniam, quis nostrud exercitation ullamco laboris nisi ut
                        aliquid ex ea<br /> commodi consequat.</p>
                </div>
                <div className=" responsive customi">
                    <h2 className="responsive1">CUSTOMIZABLE</h2>
                    <p className="responsive2">Lorem ipsum dolor sit amet, consectetur adipisci elit, sed eiusmod<br />
                        tempor incidunt ut labore et dolore magna aliqua. Ut enim ad minim<br />veniam, quis nostrud exercitation ullamco laboris nisi ut
                        aliquid ex ea<br /> commodi consequat.</p>
                </div>
                <div className="responsive modern">
                    <h2 className="responsive1">MODERN</h2>
                    <p className="responsive2">Lorem ipsum dolor sit amet, consectetur adipisci elit, sed eiusmod<br />
                        tempor incidunt ut labore et dolore magna aliqua. Ut enim ad minim<br />veniam, quis nostrud exercitation ullamco laboris nisi ut
                        aliquid ex ea<br /> commodi consequat.</p>
                </div>
            </body>
        </>
    )
}