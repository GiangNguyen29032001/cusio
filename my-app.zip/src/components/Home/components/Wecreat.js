import "./Wecreat.scss"
export default function Wecreat(){
    return(
        <body className="tongwe">
            <div className="texttongwe">
                <h2 className="wecreate">WE CREATE <strong> AWESOME</strong> PROJECTS</h2>
                <h3 className="getstart">GET STARTED</h3>
            </div>
        </body>
    )
}