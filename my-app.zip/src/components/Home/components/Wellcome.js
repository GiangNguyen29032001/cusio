import "./Wellcome.scss"
export default function Wellcome() {
    return (
        <>
            <div className="tongwellcome">
                {/* <p></p> */}
                <h2 className="chuwell">
                    WELCOME TO <strong className="doimaucru">CRUCIO</strong>
                </h2>
                <h3 className="wecre">WE CREATE AWESOME WEBSITES</h3>
                <p className="chuchitiet">Lorem ipsum dolor sit amet, consectetur adipisci elit, sed eiusmod tempor incidunt ut labore et dolore magna aliqua.
                    Ut enim ad minim veniam, quis,<br/>nostrud exercitation ullamco laboris nisi ut aliquid ex ea commodi consequat.
                    Quis aute iure reprehenderit in voluptate velit esse cillum dolore eu <br/>fugiat nulla pariatur.
                    Excepteur sint obcaecat cupiditat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
                </p>
            </div>
        </>
    )
}